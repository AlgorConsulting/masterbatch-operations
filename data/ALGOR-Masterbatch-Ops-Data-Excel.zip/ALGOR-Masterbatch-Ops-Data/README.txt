Masterbatch Plant Network — synthetic sample dataset (ALGOR Analytics)

All data is synthetic and generated for demonstration only. Amounts in Indian rupees (INR); quantities in kg and MT.
Period: Apr 2024 - Oct 2026 (Indian financial years; FY 2026-27 to date). Data as of 31 Oct 2026.

Tables:
  prod_monthly: 590 rows
  maint_monthly: 403 rows
  defects_monthly: 4,130 rows
  down_st_monthly: 3,539 rows
  down_rs_monthly: 2,515 rows
  sales_monthly: 1,798 rows
  fg_monthly: 372 rows
  inv_monthly: 527 rows
  budget_monthly: 93 rows
  shift_production_log: 22,581 rows
  stoppage_event_log: 23,767 rows
  condition_monitoring_alerts: 512 rows
  qc_batch_results_sample: 12,726 rows
  dispatch_register_sample: 13,075 rows
  daily_critical_stock: 9,264 rows
  daily_plant_dispatch_fg: 1,737 rows
  materials_spares_monthly_position: 1,023 rows
